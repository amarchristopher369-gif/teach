# ChurchTech Phase 1 Plan

## Scope

Deliver the first approval-gated phase of the ChurchTech Digital Ministry platform: a premium, responsive public experience for India-first service with worldwide ambition. This phase covers brand system, responsive navigation, homepage, public page layouts, founder portfolio separation, empty states, accessible form surfaces, and SEO route declarations. It does not claim server persistence, email delivery, Supabase/RLS, admin authorization, payments, or deployment until those later phases are approved and implemented.

## Implementation approach

- React + TypeScript + Wouter for the public route map.
- Tailwind-compatible CSS tokens plus a small, readable custom design layer in `client/src/index.css`.
- Shared `SiteShell` for desktop/mobile navigation, footer, page-level metadata, and route transitions.
- Reusable public content data in `client/src/site/data.ts` so service and portfolio content can later be migrated into CMS records without rewriting the visual system.
- CSS-built hero workspace visual to avoid invented client imagery or unverified stock photography; it depicts generic UI/creative tooling rather than a fake client project.
- Form surfaces are intentionally front-end-only in this phase. On submit they show an honest “connection pending” confirmation state rather than pretending to save or send email.
- `public/manus-routes.json` declares all public routes for the managed preview and SEO tooling.

## Design direction

### Style options

- **Editorial ministry technology** (0.06): high-contrast serif headlines, disciplined grid, warm paper surfaces, and interface-like details.
- **Quiet Swiss nonprofit** (0.04): neutral type, strict geometry, and restrained color blocks.
- **Neo-brutalist service studio** (0.03): oversized type, hard edges, and intentionally loud utility labels.

Chosen: **Editorial ministry technology**.

### Design Movement

A premium editorial technology studio: the restraint and typography of an international consultancy, softened by warm paper tones and a service-first ministry voice.

### Core Principles

1. Make the mission immediately legible: free digital capability for churches.
2. Pair generous editorial space with interface precision.
3. Use real/empty states instead of invented proof.
4. Treat mobile as a primary composition, not a collapsed desktop.

### Color Philosophy

Forest green signals rootedness and service; deep navy gives the platform an institutional, technology-led depth; warm cream gives the ministry a human, open surface; sage provides calm secondary emphasis; muted gold is reserved for moments of invitation and stewardship.

### Layout Paradigm

A left-anchored editorial rail with asymmetric content blocks: wide hero copy, a floating workspace visual, horizontal process rails, and split cards. Sections alternate between paper, white, and deep-green canvases instead of repeating a centered card grid.

### Signature Elements

- A small gold “cross-current” glyph: a cross-shaped connector line used in eyebrow labels and the logo mark.
- Interface “window” frames in the hero and work sections, evoking websites and creative tooling without claiming client work.
- Short rule lines and indexed numerals (`01`, `02`) that make the site feel like a considered service system.

### Interaction Philosophy

Interactions are quiet and useful: nav underlines, button lift, card border shifts, and progressive disclosure on mobile. No decorative motion is required for comprehension; all transforms are disabled under `prefers-reduced-motion`.

### Animation

Use opacity/translate reveals only on elements with `data-reveal`, gentle hover elevation on buttons/cards, and a restrained workspace drift. Motion must not cause layout shift or block keyboard navigation.

### Typography System

Playfair Display for editorial display headings and Inter for body, labels, form controls, and navigation. Heading sizes step from mobile `clamp(2.75rem, 10vw, 6.75rem)` down to section display `clamp(2.25rem, 5vw, 4.5rem)`; body copy stays between 0.95rem and 1.1rem with relaxed line-height.

### Brand Essence

Technology serving the Church by making professional digital capability accessible to ministries. Personality: rooted, capable, generous.

### Brand Voice

Headlines are clear and quietly confident; CTAs are direct invitations to participate. Example lines: “Technology should never be a barrier to ministry.” and “Your ministry has a message. Let’s help the world see it.”

### Wordmark & Logo

A text wordmark paired with a simple CSS/SVG symbol: canopy circles above a trunk/cross and plug base. The symbol is deliberately simple for this phase and is not presented as the supplied official production logo; it is a temporary brand-system treatment until the official asset is provided.

### Signature Brand Color

Forest green `#173D32`.

## Project structure

- `client/src/App.tsx`: route registration and app providers.
- `client/src/components/SiteShell.tsx`: shared navigation, footer, metadata, and page framing.
- `client/src/components/ChurchTechLogo.tsx`: reusable temporary wordmark/symbol treatment.
- `client/src/components/WorkspaceVisual.tsx`: CSS-built abstract technology/creative workspace.
- `client/src/site/data.ts`: public navigation, service, value, process, portfolio, and academy content.
- `client/src/pages/Home.tsx`: homepage composition.
- `client/src/pages/PublicPages.tsx`: About, Services, Work, Academy, Volunteer, Partner, Apply, Contact, Privacy, and Terms layouts.
- `client/src/index.css`: design tokens, responsive layout utilities, typography, component styles, focus states, and reduced-motion rules.
- `client/public/manus-routes.json`: complete public route manifest.
- `server/` and `drizzle/`: preserved starter foundation for later backend/auth/database phases; no fabricated workflows are wired in Phase 1.

## Later phases

1. Backend and database: add schema/migrations, secure storage, RLS-equivalent authorization, and application APIs.
2. Applications and volunteer systems: connect forms, reference IDs, notifications, validation, and upload workflows.
3. Admin dashboard: add Manus OAuth-backed sessions, least-privilege roles, CMS, project management, and finance restrictions.
4. Testing/security: verify mobile, form, authorization, storage, email, SEO, and database behavior.
5. Deployment: only after explicit user approval; no GitHub connection or publish in Phase 1.
