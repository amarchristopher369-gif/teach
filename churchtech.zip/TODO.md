# ChurchTech Phase 1 TODO

## Public brand system and responsive shell

- [x] Establish the ChurchTech visual system around Forest Green `#173D32`, Deep Green `#102A23`, Deep Navy `#14243A`, Warm Cream `#F6F3EA`, Pure White, Muted Gold `#C6A45C`, Soft Sage `#DCE8DF`, Text Dark `#1C2823`, and Secondary Text `#68746D`.
- [x] Use Playfair Display for headings and Inter for body copy, labels, navigation, buttons, and form controls.
- [x] Build a responsive navigation with Home, About, Services, Our Work, Academy, Volunteer, Contact, and a “Get Free Services” CTA; provide a keyboard-accessible mobile menu.
- [x] Add responsive layout behavior for mobile, tablet, desktop, and large desktop sizes with visible focus states and reduced-motion support.
- [ ] Replace the Phase 1 temporary logo treatment with the supplied official ChurchTech logo asset when provided.

## Public pages and content

- [x] Build Home with the hero “Technology Serving the Church.”, free digital solutions copy, “Explore Our Services” and “Partner With Us” CTAs, India/worldwide support line, trust statement, four department cards, Why ChurchTech values, four-step process, founder portfolio distinction, ChurchTech empty state, and final CTA.
- [x] Build About with why ChurchTech exists, vision, mission, values, biblical foundation, service approach, founder introduction, and founder portfolio link.
- [x] Build Services with Web, Creative, Media, and Academy departments, descriptions, audiences, included work, deliverables, and application CTAs.
- [x] Build Our Work with category filters, Founder Portfolio cards, separate ChurchTech Completed Projects empty state, and no fabricated clients, screenshots, testimonials, or statistics.
- [x] Build Academy with learning categories, resource/courses empty states, registration CTA, and no invented teachers, certificates, or completed courses.
- [x] Build Volunteer with the requested headline, role list, responsibility framing, and application form surface.
- [x] Build Partner With Us with support options, transparency copy, enquiry form surface, and no online payment collection.
- [x] Build Apply for Free Services with eligibility/scope/capacity explanation and the requested church, service, project, links, file, and consent fields as a Phase 1 form surface.
- [x] Build Contact with enquiry pathways and the provided email shown as “if confirmed as official ChurchTech contact”.
- [x] Add Privacy Policy and Terms routes with honest Phase 1 placeholder language pending legal review.

## Honest state and SEO foundations

- [x] Show functional empty states for ChurchTech projects and Academy content where no verified records exist.
- [x] Keep application forms visually complete but clearly mark that secure persistence, reference IDs, email notifications, uploads, and admin review are pending the backend phase.
- [x] Add `public/manus-routes.json` for all public routes.
- [x] Add route-aware document titles, descriptions, semantic headings, and social metadata in the shared shell.
- [ ] Add canonical origin, sitemap.xml, robots.txt, and structured data once the public origin is configured.

## Backend/admin deferred by phase gate

- [ ] Add database tables, migrations, validation, storage rules, and audit logging.
- [ ] Add Manus OAuth-backed admin authentication and least-privilege roles.
- [ ] Connect church applications, volunteer applications, partnership enquiries, contact submissions, reference IDs, notifications, and uploads.
- [ ] Build the private dashboard modules for applications, projects, volunteers, portfolio, CMS, settings, and finance.
- [ ] Run the required testing/security pass and request approval before deployment.
