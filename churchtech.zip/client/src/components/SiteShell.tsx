import { ArrowUpRight, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import ChurchTechLogo from "./ChurchTechLogo";
import { navItems } from "../site/data";

type Props = { children: React.ReactNode; title: string; description: string; eyebrow?: string; darkHeader?: boolean };

export default function SiteShell({ children, title, description, eyebrow, darkHeader = false }: Props) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    document.title = `${title} | ChurchTech`;
    const descriptionTag = document.querySelector('meta[name="description"]');
    descriptionTag?.setAttribute("content", description);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    setMenuOpen(false);
  }, [location, title, description]);

  return (
    <div className={`site-shell ${darkHeader ? "site-shell--dark" : ""}`}>
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className="site-header">
        <div className="site-header__inner">
          <Link href="/" aria-label="ChurchTech home"><ChurchTechLogo light={darkHeader} /></Link>
          <nav className="desktop-nav" aria-label="Primary navigation">
            {navItems.map(item => <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}>{item.label}</Link>)}
          </nav>
          <Link href="/apply" className="header-cta">Get Free Services <ArrowUpRight size={15} /></Link>
          <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen(open => !open)}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
        {menuOpen && <nav className="mobile-nav" aria-label="Mobile navigation">
          {navItems.map(item => <Link key={item.href} href={item.href} className={location === item.href ? "is-active" : ""}>{item.label}</Link>)}
          <Link href="/apply" className="button button--gold">Get Free Services <ArrowUpRight size={16} /></Link>
        </nav>}
      </header>
      <main id="main-content">
        {eyebrow && <div className="page-kicker"><div className="container"><span className="eyebrow"><i />{eyebrow}</span></div></div>}
        {children}
      </main>
      <footer className="site-footer">
        <div className="container site-footer__grid">
          <div className="footer-intro"><ChurchTechLogo light /><p>Our services are free. Our mission is service. Our purpose is to glorify God.</p></div>
          <div><span className="footer-label">Explore</span><div className="footer-links">{navItems.slice(1, 5).map(item => <Link key={item.href} href={item.href}>{item.label}</Link>)}</div></div>
          <div><span className="footer-label">Participate</span><div className="footer-links"><Link href="/apply">Apply for services</Link><Link href="/volunteer">Volunteer</Link><Link href="/partner">Partner with us</Link><Link href="/contact">Contact</Link></div></div>
          <div><span className="footer-label">Stay rooted</span><p className="footer-note">Serving churches in India.<br />Building connections worldwide.</p><Link href="/about" className="text-link text-link--light">Why ChurchTech <ArrowUpRight size={14} /></Link></div>
        </div>
        <div className="container footer-bottom"><span>© {new Date().getFullYear()} ChurchTech Digital Ministry</span><span className="footer-legal"><Link href="/privacy">Privacy</Link><Link href="/terms">Terms</Link></span></div>
      </footer>
    </div>
  );
}

export function Eyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return <span className={`eyebrow ${light ? "eyebrow--light" : ""}`}><i />{children}</span>;
}

export function SectionTitle({ eyebrow, title, body, light = false }: { eyebrow: string; title: string; body?: string; light?: boolean }) {
  return <div className={`section-title ${light ? "section-title--light" : ""}`}><Eyebrow light={light}>{eyebrow}</Eyebrow><h2>{title}</h2>{body && <p>{body}</p>}</div>;
}

export function ButtonLink({ href, children, variant = "primary" }: { href: string; children: React.ReactNode; variant?: "primary" | "outline" | "gold" | "text" }) {
  return <Link href={href} className={`button button--${variant}`}>{children}<ArrowUpRight size={16} /></Link>;
}
