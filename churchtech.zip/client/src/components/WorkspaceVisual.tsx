import { ArrowUpRight, Check, CirclePlay, MoreHorizontal, Plus, Sparkles } from "lucide-react";

export default function WorkspaceVisual() {
  return (
    <div className="workspace-visual" aria-label="Illustration of a digital ministry workspace">
      <div className="workspace-orbit workspace-orbit--one" />
      <div className="workspace-orbit workspace-orbit--two" />
      <div className="workspace-card workspace-card--main">
        <div className="workspace-bar"><span className="workspace-dots"><i /><i /><i /></span><span>churchtech / home</span><MoreHorizontal size={15} /></div>
        <div className="workspace-main-content"><span className="workspace-mini-label">MINISTRY DIGITAL SYSTEM</span><strong>Make the message<br /><em>easier to find.</em></strong><span className="workspace-line" /><span className="workspace-small-copy">Clarity for the church.<br />Care for the people.</span><div className="workspace-action"><span>Explore services</span><ArrowUpRight size={13} /></div></div>
        <div className="workspace-footer"><span><span className="workspace-avatar">CT</span> ChurchTech</span><span className="workspace-status"><Check size={11} /> in service</span></div>
      </div>
      <div className="workspace-card workspace-card--side"><div className="workspace-bar"><span className="workspace-dots"><i /><i /><i /></span><span>creative queue</span></div><div className="creative-stack"><span className="creative-tile creative-tile--gold">SUNDAY<br /><b>IS A<br />GIFT</b></span><span className="creative-tile creative-tile--sage"><Sparkles size={18} /><b>Make room<br />for wonder.</b></span><span className="creative-tile creative-tile--navy"><CirclePlay size={20} /><b>Stories<br />in motion.</b></span></div></div>
      <div className="workspace-card workspace-card--float"><span className="float-icon"><Plus size={16} /></span><span><b>4 departments</b><small>built to serve</small></span></div>
    </div>
  );
}
