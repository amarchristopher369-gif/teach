import { Plug } from "lucide-react";

type Props = { compact?: boolean; light?: boolean };

export default function ChurchTechLogo({ compact = false, light = false }: Props) {
  const ink = light ? "#F6F3EA" : "#173D32";
  const accent = light ? "#C6A45C" : "#C6A45C";
  return (
    <span className={`brand-lockup ${compact ? "brand-lockup--compact" : ""}`} aria-label="ChurchTech">
      <span className="brand-symbol" aria-hidden="true">
        <span className="brand-canopy brand-canopy--one" style={{ background: ink }} />
        <span className="brand-canopy brand-canopy--two" style={{ background: ink }} />
        <span className="brand-canopy brand-canopy--three" style={{ background: ink }} />
        <span className="brand-trunk" style={{ background: ink }} />
        <span className="brand-cross" style={{ background: ink }} />
        <Plug size={10} strokeWidth={2.6} className="brand-plug" color={accent} />
      </span>
      {!compact && <span className="brand-copy"><strong style={{ color: ink }}>ChurchTech</strong><small style={{ color: light ? "#DCE8DF" : "#68746D" }}>Technology Serving the Church.</small></span>}
    </span>
  );
}
