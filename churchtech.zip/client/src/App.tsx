import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";
import { About, Academy, Apply, Contact, Legal, Partner, Services, Volunteer, Work } from "./pages/PublicPages";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/about" component={About} />
    <Route path="/services" component={Services} />
    <Route path="/work" component={Work} />
    <Route path="/academy" component={Academy} />
    <Route path="/volunteer" component={Volunteer} />
    <Route path="/partner" component={Partner} />
    <Route path="/apply" component={Apply} />
    <Route path="/contact" component={Contact} />
    <Route path="/privacy"><Legal kind="privacy" /></Route>
    <Route path="/terms"><Legal kind="terms" /></Route>
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary>
    <ThemeProvider defaultTheme="light">
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </ThemeProvider>
  </ErrorBoundary>;
}
