import { ArrowRight, ArrowUpRight, Check, Globe2, HeartHandshake, Lightbulb, Orbit, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import ChurchTechLogo from "../components/ChurchTechLogo";
import SiteShell, { ButtonLink, SectionTitle } from "../components/SiteShell";
import WorkspaceVisual from "../components/WorkspaceVisual";
import { founderProjects, processSteps, services, values } from "../site/data";

const valueIcons = [HeartHandshake, ShieldCheck, Globe2, Lightbulb];

export default function Home() {
  return (
    <SiteShell title="Technology Serving the Church" description="ChurchTech is an independent Christian digital ministry providing free website development, graphic design, video editing and digital training to churches and Christian ministries.">
      <section className="hero-section">
        <div className="container hero-grid">
          <div className="hero-copy" data-reveal>
            <span className="eyebrow"><i />Independent Christian digital ministry</span>
            <h1>Technology<br /><em>serving the Church.</em></h1>
            <p className="hero-lede">Empowering churches through free digital solutions, creative excellence and technology that advances the Gospel.</p>
            <div className="hero-actions"><ButtonLink href="/services">Explore our services</ButtonLink><ButtonLink href="/partner" variant="outline">Partner with us</ButtonLink></div>
            <div className="hero-note"><span className="note-mark"><Check size={12} /></span><span>Serving churches in India.<br /><b>Building connections worldwide.</b></span></div>
          </div>
          <div className="hero-visual" data-reveal><WorkspaceVisual /><span className="hero-stamp"><Orbit size={16} /> Built for service</span></div>
        </div>
        <div className="container hero-bottomline"><span>01 / 04</span><span className="hero-rule" /><span>Digital capability for ministry</span></div>
      </section>

      <section className="trust-band"><div className="container trust-band__inner"><span className="eyebrow"><i />A conviction we carry</span><p>Every church deserves access to quality digital resources, regardless of its financial capacity.</p><ArrowRight size={20} /></div></section>

      <section className="section section--cream">
        <div className="container"><SectionTitle eyebrow="What we do" title="Four ways to move your ministry forward." body="From your first digital home to the skills that keep it useful, ChurchTech brings technology and service into the same room." />
          <div className="service-grid">{services.map(service => { const Icon = service.icon; return <Link href="/services" className={`service-card service-card--${service.tone}`} key={service.name}><div className="service-card__top"><span className="index-number">{service.number}</span><Icon size={23} strokeWidth={1.7} /></div><div><span className="card-eyebrow">{service.eyebrow}</span><h3>{service.name}</h3><p>{service.description}</p></div><span className="card-link">Explore department <ArrowUpRight size={15} /></span></Link>; })}</div>
        </div>
      </section>

      <section className="section section--white values-section"><div className="container values-layout"><div className="values-intro"><span className="eyebrow"><i />Why ChurchTech</span><h2>Technology should never be a barrier to ministry.</h2><p>We are building a digital ministry where quality is not reserved for the organizations with the biggest budgets.</p><Link href="/about" className="text-link">Read our story <ArrowUpRight size={15} /></Link></div><div className="values-list">{values.map((value, index) => { const Icon = valueIcons[index]; return <div className="value-row" key={value.title}><span className="value-icon"><Icon size={18} /></span><div><h3>{value.title}</h3><p>{value.text}</p></div></div>; })}</div></div></section>

      <section className="section section--green process-section"><div className="container"><div className="process-heading"><SectionTitle eyebrow="How it works" title="A clear path from need to next step." body="The first step is always a conversation. We keep the rest as clear as we can." light /><Link href="/apply" className="button button--gold">Apply for free services <ArrowUpRight size={16} /></Link></div><div className="process-grid">{processSteps.map(step => <div className="process-step" key={step.number}><span className="process-number">{step.number}</span><h3>{step.title}</h3><p>{step.text}</p></div>)}</div></div></section>

      <section className="section section--cream work-preview"><div className="container"><div className="split-heading"><SectionTitle eyebrow="Founder portfolio" title="Experience that starts with making." body="Before ChurchTech’s first official client projects, there is a founder portfolio: a place to explore Amar Christopher’s development practice and existing work." /><Link href="/work" className="text-link">View portfolio work <ArrowUpRight size={15} /></Link></div><div className="founder-work-grid">{founderProjects.slice(0, 3).map(project => <a className={`founder-card founder-card--${project.accent}`} href={project.href} target="_blank" rel="noreferrer" key={project.title}><span className="founder-card__visual"><span className="visual-window"><i /><i /><i /></span><span className="visual-word">{project.title.split(" ")[0]}</span></span><span className="founder-card__meta"><span><small>{project.category}</small><strong>{project.title}</strong></span><ArrowUpRight size={17} /></span></a>)}</div><div className="empty-state empty-state--inline"><span className="empty-state__icon"><Orbit size={20} /></span><div><span className="card-eyebrow">ChurchTech completed projects</span><h3>Our journey of serving churches is beginning.</h3><p>Our first projects will appear here soon. We will only publish verified work completed under ChurchTech.</p></div><Link href="/work" className="button button--outline">See the distinction <ArrowUpRight size={15} /></Link></div></div></section>

      <section className="cta-section"><div className="container cta-section__inner"><div className="cta-mark"><ChurchTechLogo compact light /></div><div><span className="eyebrow eyebrow--light"><i />The next chapter</span><h2>Your ministry has a message.<br /><em>Let’s help the world see it.</em></h2></div><ButtonLink href="/apply" variant="gold">Apply for free services</ButtonLink></div></section>
    </SiteShell>
  );
}
