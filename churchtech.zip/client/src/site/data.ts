import type { LucideIcon } from "lucide-react";
import { ArrowUpRight, Brush, Clapperboard, Laptop, Sparkles } from "lucide-react";

export type Service = {
  number: string;
  name: string;
  eyebrow: string;
  description: string;
  audience: string;
  deliverables: string[];
  icon: LucideIcon;
  tone: "green" | "cream" | "navy" | "sage";
};

export const navItems = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/work", label: "Our Work" },
  { href: "/academy", label: "Academy" },
  { href: "/volunteer", label: "Volunteer" },
  { href: "/contact", label: "Contact" },
];

export const services: Service[] = [
  {
    number: "01",
    name: "ChurchTech Web",
    eyebrow: "Digital foundations",
    description: "Professional church and ministry websites that make your message easier to find, trust and act on.",
    audience: "For churches, ministries, pastors and events building a clearer digital home.",
    deliverables: ["Church and ministry websites", "Prayer and contact forms", "Redesign, maintenance and resource libraries"],
    icon: Laptop,
    tone: "green",
  },
  {
    number: "02",
    name: "ChurchTech Creative",
    eyebrow: "Visual communication",
    description: "Thoughtful graphics that help sermons, gatherings and stories travel further across every screen.",
    audience: "For church teams that need a consistent visual voice without a full-time designer.",
    deliverables: ["Sermon posters and event banners", "Social media templates and thumbnails", "Branding, slides and conference design"],
    icon: Brush,
    tone: "cream",
  },
  {
    number: "03",
    name: "ChurchTech Media",
    eyebrow: "Stories in motion",
    description: "Clear, purposeful editing for the sermons, testimonies and moments your community wants to share.",
    audience: "For churches and ministries turning recordings into useful digital media.",
    deliverables: ["Sermon, testimony and event edits", "Reels, Shorts and YouTube preparation", "Subtitles, captions and basic optimization"],
    icon: Clapperboard,
    tone: "navy",
  },
  {
    number: "04",
    name: "ChurchTech Academy",
    eyebrow: "Skills for service",
    description: "Practical training that helps pastors, volunteers and ministry teams steward digital tools with confidence.",
    audience: "For churches building sustainable in-house digital capability.",
    deliverables: ["Canva, design and video fundamentals", "Website and social media management", "Digital skills for pastors and volunteers"],
    icon: Sparkles,
    tone: "sage",
  },
];

export const values = [
  { title: "Free core services", text: "Professional digital help should be accessible to churches regardless of financial capacity." },
  { title: "Professional quality", text: "We bring care, clarity and craft to the details that help a ministry be understood." },
  { title: "Church-centered approach", text: "The technology serves the ministry, never the other way around." },
  { title: "Technology with purpose", text: "Every page, frame and lesson should move a real message forward." },
];

export const processSteps = [
  { number: "01", title: "Apply for a service", text: "Tell us what your church needs and where you are trying to go." },
  { number: "02", title: "We review the brief", text: "We look at fit, scope and current capacity before getting back to you." },
  { number: "03", title: "Our team gets to work", text: "A focused team shapes the digital, creative or training work with you." },
  { number: "04", title: "Receive your project", text: "You receive a useful, considered result and the next step to sustain it." },
];

export const founderProjects = [
  { title: "Called to Cultivate", category: "Ministry website", text: "A founder portfolio project exploring a clearer digital home for ministry work.", accent: "mint", href: "https://amarchristopher369-gif.github.io/potfolio/" },
  { title: "Institute Website", category: "Educational website", text: "A founder portfolio project focused on structured information and learning journeys.", accent: "cream", href: "https://amarchristopher369-gif.github.io/potfolio/" },
  { title: "Christopher Website", category: "Product website", text: "A founder portfolio project exploring product storytelling and focused calls to action.", accent: "navy", href: "https://amarchristopher369-gif.github.io/potfolio/" },
  { title: "Time Management", category: "Digital tool", text: "A founder portfolio project for making personal organization feel more intentional.", accent: "gold", href: "https://amarchristopher369-gif.github.io/potfolio/" },
];

export const academyCategories = ["Graphic Design", "Website Management", "Video Editing", "Digital Ministry", "Social Media", "Technology Fundamentals"];
export const volunteerRoles = ["Web Developer", "Graphic Designer", "Video Editor", "UI/UX Designer", "Social Media Volunteer", "Digital Trainer", "Project Coordinator", "Technical Support"];
export const partnershipOptions = ["Individual supporter", "Church partnership", "Christian business sponsor", "Technology or equipment donor", "Professional volunteer"];

export const fieldMeta = {
  countries: ["India", "United States", "United Kingdom", "Canada", "Australia", "Other"],
  services: ["Website development", "Graphic design", "Video editing", "Digital training"],
  timelines: ["As soon as possible", "Within 1 month", "Within 3 months", "Flexible / exploring"],
  enquiryTypes: ["General enquiry", "Service enquiry", "Volunteer enquiry", "Partnership enquiry"],
};

export const iconLink = ArrowUpRight;
